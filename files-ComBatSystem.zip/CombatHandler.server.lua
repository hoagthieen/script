--[[
    📁 VỊ TRÍ FILE: ServerScriptService > CombatHandler.server.lua
    📌 LOẠI: Script (Server)
    🔧 CÁCH TẠO:
        1. Vào ServerScriptService
        2. Insert > Script
        3. Đổi tên thành "CombatHandler"
        4. Paste code này vào

    📋 CHỨC NĂNG CHÍNH:
        - Nhận yêu cầu từ Client (M1, Block, Dash)
        - Validate và xử lý logic
        - Gọi HitboxManager để detect hit
        - Gọi StatusEffectHandler để áp stun/knockback
        - Quản lý Stamina, Cooldown, Combo count
        - Trả kết quả về Client

    ⚠️ SERVER-AUTHORITATIVE: Mọi logic đều xử lý server
--]]

local Players          = game:GetService("Players")
local RunService       = game:GetService("RunService")

-- ══════════════════════════════════════════
--       REQUIRE MODULES
-- ══════════════════════════════════════════
local Config           = require(game.ReplicatedStorage.Shared.CombatConfig)
local ComboData        = require(game.ReplicatedStorage.Shared.ComboData)
local Remotes          = require(game.ReplicatedStorage.Shared.RemoteEvents)
local HitboxManager    = require(game.ServerScriptService.HitboxManager)
local StatusHandler    = require(game.ServerScriptService.StatusEffectHandler)

-- ══════════════════════════════════════════
--       DỮ LIỆU NGƯỜI CHƠI
-- ══════════════════════════════════════════
local playerData = {}

local function initPlayerData(player)
    playerData[player] = {
        -- Stats
        hp              = Config.Player.MaxHP,
        stamina         = Config.Stamina.Max,

        -- Combo
        comboCount      = 0,
        lastHitTime     = 0,
        comboCooldown   = false,

        -- Cooldowns
        m1Cooldown      = false,
        dashCooldown    = false,

        -- Stamina regen
        staminaRegenTimer = 0,
        lastStaminaUse    = 0,
    }
end

local function getData(player)
    return playerData[player]
end

-- ══════════════════════════════════════════
--       KHỞI TẠO PLAYER
-- ══════════════════════════════════════════
Players.PlayerAdded:Connect(function(player)
    initPlayerData(player)

    player.CharacterAdded:Connect(function(character)
        -- Đặt lại HP khi respawn
        local data = getData(player)
        if data then
            data.hp      = Config.Player.MaxHP
            data.stamina = Config.Stamina.Max
            data.comboCount = 0
        end

        local humanoid = character:WaitForChild("Humanoid")
        humanoid.MaxHealth = Config.Player.MaxHP
        humanoid.Health    = Config.Player.MaxHP
    end)
end)

Players.PlayerRemoving:Connect(function(player)
    playerData[player] = nil
end)

-- ══════════════════════════════════════════
--       HÀM TIÊU STAMINA
-- ══════════════════════════════════════════
local function consumeStamina(player, amount)
    local data = getData(player)
    if not data then return false end
    if data.stamina < amount then return false end -- Không đủ stamina

    data.stamina = math.max(0, data.stamina - amount)
    data.lastStaminaUse = tick()

    -- Gửi cập nhật UI về client
    Remotes.OnStaminaUpdate:FireClient(player, data.stamina, Config.Stamina.Max)
    return true
end

-- ══════════════════════════════════════════
--       HỒI STAMINA (chạy mỗi frame)
-- ══════════════════════════════════════════
RunService.Heartbeat:Connect(function(dt)
    for player, data in pairs(playerData) do
        local now = tick()

        -- Chờ RegenDelay trước khi hồi
        if now - data.lastStaminaUse >= Config.Stamina.RegenDelay then
            if data.stamina < Config.Stamina.Max then
                data.stamina = math.min(
                    Config.Stamina.Max,
                    data.stamina + Config.Stamina.RegenRate * dt
                )
                Remotes.OnStaminaUpdate:FireClient(player, data.stamina, Config.Stamina.Max)
            end
        end

        -- Tiêu stamina khi đang block
        if StatusHandler.IsBlocking(player) then
            data.stamina = math.max(0, data.stamina - Config.Stamina.BlockCostPerSec * dt)
            data.lastStaminaUse = now
            Remotes.OnStaminaUpdate:FireClient(player, data.stamina, Config.Stamina.Max)

            -- Hết stamina → tự động bỏ block
            if data.stamina <= 0 then
                StatusHandler.SetBlocking(player, false)
                local character = player.Character
                if character then
                    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
                    if humanoid then
                        humanoid.WalkSpeed = Config.Player.WalkSpeed
                    end
                end
            end
        end
    end
end)

-- ══════════════════════════════════════════
--       XỬ LÝ M1 COMBO
-- ══════════════════════════════════════════
Remotes.RequestM1.OnServerEvent:Connect(function(player)
    local data = getData(player)
    if not data then return end

    -- ── Kiểm tra điều kiện ──
    if data.m1Cooldown then return end
    if StatusHandler.IsStunned(player) then return end
    if StatusHandler.IsRagdoll(player) then return end

    local character = player.Character
    if not character then return end
    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
    if not humanoid or humanoid.Health <= 0 then return end

    -- ── Xử lý combo count ──
    local now = tick()
    if now - data.lastHitTime > Config.M1.ComboResetTime then
        data.comboCount = 0 -- Reset nếu quá lâu
    end

    data.comboCount = data.comboCount + 1
    if data.comboCount > Config.M1.MaxCombo then
        data.comboCount = 1 -- Reset về đòn 1
    end

    local currentCombo = data.comboCount
    data.lastHitTime   = now

    -- ── Bật cooldown ──
    data.m1Cooldown = true
    task.delay(Config.M1.CooldownPerHit, function()
        data.m1Cooldown = false
    end)

    -- ── Phát animation (gửi tất cả clients để thấy) ──
    local animId = ComboData.M1Animations[currentCombo]
    Remotes.PlayAnimation:FireAllClients(player, animId, "M1_" .. currentCombo)

    -- ── Cập nhật combo UI ──
    Remotes.OnComboUpdate:FireClient(player, currentCombo, Config.M1.MaxCombo)

    -- ── Detect hitbox ──
    task.wait(0.1) -- Đợi animation bắt đầu rồi mới check hit

    local hitResults = HitboxManager.CreateHitbox(player)

    for _, result in ipairs(hitResults) do
        local targetPlayer = result.player
        local targetData   = targetPlayer and getData(targetPlayer)

        -- ── Kiểm tra target đang dash (iframe) ──
        if StatusHandler.IsDashing(targetPlayer or {}) then continue end

        -- ── Kiểm tra block ──
        local isBlocked = StatusHandler.IsBlocking(targetPlayer or {})

        -- ── Tính damage ──
        local baseDamage = Config.Damage.M1[currentCombo] or 10
        local finalDamage = isBlocked
            and (baseDamage * (1 - Config.Damage.BlockReduction))
            or baseDamage

        -- ── Áp damage ──
        result.humanoid:TakeDamage(finalDamage)

        -- ── Tính lực knockback ──
        local isFinalBlow = ComboData.M1Data[currentCombo].isFinalBlow
        local knockbackForce = isFinalBlow
            and Config.Knockback.M1Final
            or  Config.Knockback.M1Base

        if not isBlocked then
            -- Stun
            local stunDur = isFinalBlow
                and Config.Knockback.FinalStunDuration
                or  Config.Knockback.StunDuration
            StatusHandler.ApplyStun(targetPlayer, stunDur)

            -- Knockback
            StatusHandler.ApplyKnockback(targetPlayer, player, knockbackForce)

            -- Ragdoll đòn cuối
            if isFinalBlow then
                StatusHandler.ApplyRagdoll(targetPlayer, Config.Knockback.RagdollDuration)
            end

            -- Thông báo target bị damage
            Remotes.OnDamaged:FireClient(targetPlayer, finalDamage, isFinalBlow)
        else
            -- Bị block: tiêu thêm stamina target
            if targetData then
                consumeStamina(targetPlayer, Config.Stamina.BlockHitCost)
            end
            Remotes.OnBlocked:FireClient(targetPlayer, finalDamage)
        end

        -- Thông báo attacker hit thành công
        Remotes.OnHitConfirmed:FireClient(player, targetPlayer, finalDamage, isBlocked)
    end
end)

-- ══════════════════════════════════════════
--       XỬ LÝ BLOCK
-- ══════════════════════════════════════════
Remotes.RequestBlock.OnServerEvent:Connect(function(player)
    local data = getData(player)
    if not data then return end
    if StatusHandler.IsStunned(player) then return end
    if data.stamina <= 0 then return end

    local character = player.Character
    if not character then return end
    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
    if not humanoid then return end

    StatusHandler.SetBlocking(player, true)
    humanoid.WalkSpeed = Config.Player.BlockWalkSpeed

    Remotes.PlayAnimation:FireAllClients(player, ComboData.BlockAnimation, "Block")
end)

Remotes.RequestBlockEnd.OnServerEvent:Connect(function(player)
    StatusHandler.SetBlocking(player, false)

    local character = player.Character
    if not character then return end
    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
    if humanoid then
        humanoid.WalkSpeed = Config.Player.WalkSpeed
    end

    Remotes.StopAnimation:FireAllClients(player, "Block")
end)

-- ══════════════════════════════════════════
--       XỬ LÝ DASH
-- ══════════════════════════════════════════
Remotes.RequestDash.OnServerEvent:Connect(function(player, dashDirection)
    local data = getData(player)
    if not data then return end
    if data.dashCooldown then return end
    if StatusHandler.IsStunned(player) then return end

    -- Kiểm tra stamina
    if not consumeStamina(player, Config.Stamina.DashCost) then return end

    local character = player.Character
    if not character then return end
    local rootPart = character:FindFirstChild("HumanoidRootPart")
    if not rootPart then return end

    -- ── Bật Cooldown ──
    data.dashCooldown = true
    task.delay(Config.Dash.Cooldown, function()
        data.dashCooldown = false
    end)

    -- ── Bật iframe ──
    StatusHandler.SetDashing(player, true)
    task.delay(Config.Dash.IframeDuration, function()
        StatusHandler.SetDashing(player, false)
    end)

    -- ── Phát animation ──
    Remotes.PlayAnimation:FireAllClients(player, ComboData.DashAnimation, "Dash")

    -- ── Áp lực dash ──
    local safeDirection = (dashDirection and dashDirection.Magnitude > 0)
        and dashDirection.Unit
        or  -rootPart.CFrame.LookVector

    local dashVelocity = Instance.new("LinearVelocity")
    dashVelocity.MaxForce        = math.huge
    dashVelocity.RelativeTo      = Enum.ActuatorRelativeTo.World
    dashVelocity.Attachment0     = rootPart:FindFirstChild("RootAttachment") or Instance.new("Attachment", rootPart)
    dashVelocity.VectorVelocity  = safeDirection * Config.Dash.Speed
    dashVelocity.Parent          = rootPart

    game:GetService("Debris"):AddItem(dashVelocity, Config.Dash.Duration)
end)

print("[CombatHandler] ✅ Đã khởi động thành công!")
