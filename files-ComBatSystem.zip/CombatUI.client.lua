--[[
    📁 VỊ TRÍ FILE: StarterGui > CombatUI.client.lua
    📌 LOẠI: LocalScript (đặt bên trong ScreenGui)
    🔧 CÁCH TẠO:
        1. Vào StarterGui
        2. Insert > ScreenGui, đổi tên "CombatUI"
        3. Bên trong ScreenGui → Insert > LocalScript
        4. Đổi tên LocalScript thành "CombatUI"
        5. Paste code này vào LocalScript

    📋 CHỨC NĂNG:
        - Thanh HP màu đỏ (góc trên bên trái)
        - Thanh Stamina màu vàng (dưới thanh HP)
        - Hiển thị số combo M1 (giữa màn hình)
        - Thông báo Block / Hit Confirm nhỏ

    ⚠️ Script này TỰ ĐỘNG tạo UI elements
       Không cần tạo thủ công trong Explorer
--]]

local Players      = game:GetService("Players")
local TweenService = game:GetService("TweenService")

local player  = Players.LocalPlayer
local Remotes = require(game.ReplicatedStorage.Shared.RemoteEvents)
local Config  = require(game.ReplicatedStorage.Shared.CombatConfig)

-- ══════════════════════════════════════════
--       TẠO UI TỰ ĐỘNG
-- ══════════════════════════════════════════
local screenGui = script.Parent -- ScreenGui chứa script này

-- ── Hàm tạo Frame nhanh ──
local function makeFrame(parent, name, pos, size, color, transparency)
    local f = Instance.new("Frame")
    f.Name            = name
    f.AnchorPoint     = Vector2.new(0, 0)
    f.Position        = pos
    f.Size            = size
    f.BackgroundColor3 = color or Color3.fromRGB(30, 30, 30)
    f.BackgroundTransparency = transparency or 0
    f.BorderSizePixel = 0
    f.Parent          = parent
    return f
end

local function makeLabel(parent, name, text, pos, size, color, fontSize)
    local l = Instance.new("TextLabel")
    l.Name            = name
    l.AnchorPoint     = Vector2.new(0.5, 0.5)
    l.Position        = pos
    l.Size            = size
    l.Text            = text
    l.TextColor3      = color or Color3.fromRGB(255, 255, 255)
    l.Font            = Enum.Font.GothamBold
    l.TextScaled      = true
    l.BackgroundTransparency = 1
    l.Parent          = parent
    return l
end

-- ══════════════════════════════════════════
--       THANH HP
-- ══════════════════════════════════════════
local hpContainer = makeFrame(screenGui, "HPContainer",
    UDim2.new(0, 20, 0, 20),
    UDim2.new(0, 250, 0, 28),
    Color3.fromRGB(50, 0, 0)
)
Instance.new("UICorner", hpContainer).CornerRadius = UDim.new(0, 6)

local hpBar = makeFrame(hpContainer, "HPBar",
    UDim2.new(0, 0, 0, 0),
    UDim2.new(1, 0, 1, 0),
    Color3.fromRGB(220, 40, 40)
)
Instance.new("UICorner", hpBar).CornerRadius = UDim.new(0, 6)

local hpLabel = makeLabel(hpContainer, "HPLabel", "HP: 100 / 100",
    UDim2.new(0.5, 0, 0.5, 0),
    UDim2.new(1, 0, 1, 0),
    Color3.fromRGB(255, 255, 255)
)
hpLabel.ZIndex = 2

-- ══════════════════════════════════════════
--       THANH STAMINA
-- ══════════════════════════════════════════
local staminaContainer = makeFrame(screenGui, "StaminaContainer",
    UDim2.new(0, 20, 0, 54),
    UDim2.new(0, 250, 0, 16),
    Color3.fromRGB(40, 40, 0)
)
Instance.new("UICorner", staminaContainer).CornerRadius = UDim.new(0, 4)

local staminaBar = makeFrame(staminaContainer, "StaminaBar",
    UDim2.new(0, 0, 0, 0),
    UDim2.new(1, 0, 1, 0),
    Color3.fromRGB(220, 180, 0)
)
Instance.new("UICorner", staminaBar).CornerRadius = UDim.new(0, 4)

-- ══════════════════════════════════════════
--       COMBO COUNTER (giữa màn hình)
-- ══════════════════════════════════════════
local comboContainer = Instance.new("Frame")
comboContainer.Name               = "ComboContainer"
comboContainer.AnchorPoint        = Vector2.new(0.5, 1)
comboContainer.Position           = UDim2.new(0.5, 0, 0.85, 0)
comboContainer.Size               = UDim2.new(0, 120, 0, 60)
comboContainer.BackgroundTransparency = 1
comboContainer.Parent             = screenGui

local comboNumber = makeLabel(comboContainer, "ComboNumber", "",
    UDim2.new(0.5, 0, 0.4, 0),
    UDim2.new(1, 0, 0.6, 0),
    Color3.fromRGB(255, 220, 50)
)
comboNumber.Font = Enum.Font.GothamBlack

local comboText = makeLabel(comboContainer, "ComboText", "COMBO",
    UDim2.new(0.5, 0, 0.85, 0),
    UDim2.new(1, 0, 0.35, 0),
    Color3.fromRGB(255, 255, 255)
)

comboContainer.Visible = false

-- ══════════════════════════════════════════
--       HÀM CẬP NHẬT HP
-- ══════════════════════════════════════════
local function updateHP(current, max)
    local ratio = math.clamp(current / max, 0, 1)

    TweenService:Create(hpBar, TweenInfo.new(0.2), {
        Size = UDim2.new(ratio, 0, 1, 0)
    }):Play()

    hpLabel.Text = string.format("HP: %d / %d", math.ceil(current), max)

    -- Đổi màu khi HP thấp
    if ratio < 0.3 then
        hpBar.BackgroundColor3 = Color3.fromRGB(255, 80, 0)  -- Cam khi thấp
    else
        hpBar.BackgroundColor3 = Color3.fromRGB(220, 40, 40)
    end
end

-- ══════════════════════════════════════════
--       HÀM CẬP NHẬT STAMINA
-- ══════════════════════════════════════════
local function updateStamina(current, max)
    local ratio = math.clamp(current / max, 0, 1)

    TweenService:Create(staminaBar, TweenInfo.new(0.15), {
        Size = UDim2.new(ratio, 0, 1, 0)
    }):Play()

    -- Màu đỏ khi sắp hết stamina
    if ratio < 0.25 then
        staminaBar.BackgroundColor3 = Color3.fromRGB(220, 50, 0)
    else
        staminaBar.BackgroundColor3 = Color3.fromRGB(220, 180, 0)
    end
end

-- ══════════════════════════════════════════
--       HÀM HIỆN COMBO
-- ══════════════════════════════════════════
local comboHideThread

local function showCombo(current, max)
    comboContainer.Visible = true
    comboNumber.Text = tostring(current)

    -- Hiệu ứng scale khi combo
    comboNumber.Size = UDim2.new(1.3, 0, 0.78, 0)
    TweenService:Create(comboNumber, TweenInfo.new(0.15), {
        Size = UDim2.new(1, 0, 0.6, 0)
    }):Play()

    -- Màu sắc theo số combo
    if current >= Config.M1.MaxCombo then
        comboNumber.TextColor3 = Color3.fromRGB(255, 60, 60) -- Đỏ đòn cuối
    elseif current >= 3 then
        comboNumber.TextColor3 = Color3.fromRGB(255, 140, 0)  -- Cam combo 3+
    else
        comboNumber.TextColor3 = Color3.fromRGB(255, 220, 50) -- Vàng bình thường
    end

    -- Ẩn sau 1.5 giây nếu không combo tiếp
    if comboHideThread then task.cancel(comboHideThread) end
    comboHideThread = task.delay(1.5, function()
        comboContainer.Visible = false
    end)
end

-- ══════════════════════════════════════════
--       KẾT NỐI REMOTE EVENTS
-- ══════════════════════════════════════════

-- Cập nhật stamina
Remotes.OnStaminaUpdate.OnClientEvent:Connect(function(current, max)
    updateStamina(current, max)
end)

-- Cập nhật combo
Remotes.OnComboUpdate.OnClientEvent:Connect(function(current, max)
    showCombo(current, max)
end)

-- ══════════════════════════════════════════
--       CẬP NHẬT HP TỪ HUMANOID
-- ══════════════════════════════════════════
local function connectHP()
    local character = player.Character or player.CharacterAdded:Wait()
    local humanoid  = character:WaitForChild("Humanoid")

    -- Cập nhật ngay khi load
    updateHP(humanoid.Health, humanoid.MaxHealth)

    humanoid.HealthChanged:Connect(function(hp)
        updateHP(hp, humanoid.MaxHealth)
    end)
end

player.CharacterAdded:Connect(connectHP)
if player.Character then connectHP() end

-- ══════════════════════════════════════════
--       KHỞI TẠO UI
-- ══════════════════════════════════════════
updateStamina(Config.Stamina.Max, Config.Stamina.Max)
updateHP(Config.Player.MaxHP, Config.Player.MaxHP)

print("[CombatUI] ✅ UI đã tải xong!")
