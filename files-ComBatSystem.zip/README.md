# ⚔️ TSB Combat System - Hướng Dẫn Cài Đặt

## 📁 CẤU TRÚC THƯ MỤC TRONG ROBLOX STUDIO

```
game
├── ServerScriptService
│   ├── CombatHandler.server.lua       ← Server xử lý combat chính
│   ├── HitboxManager.server.lua       ← Tạo & kiểm tra hitbox
│   └── StatusEffectHandler.server.lua ← Xử lý stun, knockback, ragdoll
│
├── ReplicatedStorage
│   └── Shared
│       ├── CombatConfig.lua           ← Cấu hình toàn bộ số liệu combat
│       ├── ComboData.lua              ← Dữ liệu chuỗi combo M1
│       └── RemoteEvents.lua           ← Tạo & lưu RemoteEvent/Function
│
├── StarterPlayerScripts
│   ├── CombatClient.client.lua        ← Client nhận input, gửi lên server
│   └── AnimationController.client.lua ← Phát animation phía client
│
└── StarterGui
    └── CombatUI
        └── CombatUI.client.lua        ← UI thanh HP, Stamina, M hiệu ứng
```

## 🚀 CÁCH CÀI ĐẶT

1. Mở **Roblox Studio** → tạo project mới (Baseplate)
2. Tạo đúng theo cấu trúc thư mục trên
3. Copy từng file vào đúng vị trí theo hướng dẫn trong mỗi file
4. Đảm bảo `ReplicatedStorage` có folder tên **Shared**
5. Chạy **Playtest** và test combat

## ⚙️ TÍNH NĂNG

- ✅ M1 Combo 5 đòn (giống TSB)
- ✅ Knockback & Ragdoll
- ✅ Block (giảm damage 80%)
- ✅ Dash (iframe 0.3s)
- ✅ Stamina system
- ✅ Hitbox detection phía server
- ✅ Animation controller
- ✅ Status Effects (Stun, Knockback)
- ✅ UI thanh HP & Stamina
