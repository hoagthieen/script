--[[
    📁 VỊ TRÍ FILE: ReplicatedStorage > Shared > ComboData.lua
    📌 LOẠI: ModuleScript
    🔧 CÁCH TẠO:
        1. Vào ReplicatedStorage > Shared
        2. Insert > ModuleScript
        3. Đổi tên thành "ComboData"
        4. Paste code này vào

    ⚠️ LƯU Ý:
        - Thay thế AnimationId bằng ID animation thực của bạn
        - Upload animation vào Roblox rồi lấy ID từ URL
        - Ví dụ: https://www.roblox.com/catalog/123456789 → ID là 123456789
--]]

local ComboData = {}

-- ══════════════════════════════════════════
--          ANIMATION IDs (THAY THẾ)
-- ══════════════════════════════════════════
-- Hướng dẫn: Upload animation lên Roblox Studio
-- Tools > Asset Manager > Animations > Import
-- Sau đó copy Animation ID vào đây

ComboData.M1Animations = {
    [1] = "rbxassetid://0000000001", -- Đòn 1: Đấm tay phải ngang
    [2] = "rbxassetid://0000000002", -- Đòn 2: Đấm tay trái uppercut
    [3] = "rbxassetid://0000000003", -- Đòn 3: Đạp chân phải
    [4] = "rbxassetid://0000000004", -- Đòn 4: Đấm tay phải mạnh
    [5] = "rbxassetid://0000000005", -- Đòn 5: Uppercut tung lên (Final Blow)
}

ComboData.DashAnimation     = "rbxassetid://0000000006" -- Animation dash
ComboData.BlockAnimation    = "rbxassetid://0000000007" -- Animation block (idle)
ComboData.BlockHitAnimation = "rbxassetid://0000000008" -- Animation khi đỡ đòn thành công
ComboData.RagdollAnimation  = "rbxassetid://0000000009" -- Animation ragdoll bay người

-- ══════════════════════════════════════════
--          HIỆU ỨNG TỪNG ĐÒN
-- ══════════════════════════════════════════
-- hitSoundId: Sound ID tiếng đấm
-- isFinalBlow: có phải đòn cuối không
-- cameraShake: rung camera (magnitude)
-- particleEffect: hiệu ứng particle khi trúng

ComboData.M1Data = {
    [1] = {
        hitSoundId    = "rbxassetid://9120386471",
        isFinalBlow   = false,
        cameraShake   = 0.3,
        particleEffect = "Normal",
    },
    [2] = {
        hitSoundId    = "rbxassetid://9120386471",
        isFinalBlow   = false,
        cameraShake   = 0.3,
        particleEffect = "Normal",
    },
    [3] = {
        hitSoundId    = "rbxassetid://9120386471",
        isFinalBlow   = false,
        cameraShake   = 0.4,
        particleEffect = "Normal",
    },
    [4] = {
        hitSoundId    = "rbxassetid://9120386471",
        isFinalBlow   = false,
        cameraShake   = 0.5,
        particleEffect = "Normal",
    },
    [5] = {
        hitSoundId    = "rbxassetid://9120386472", -- Tiếng đánh mạnh hơn
        isFinalBlow   = true,
        cameraShake   = 1.0,
        particleEffect = "Heavy",  -- Hiệu ứng mạnh hơn
    },
}

return ComboData
