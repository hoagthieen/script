--[[
    📁 VỊ TRÍ FILE: ServerScriptService > StatusEffectHandler.server.lua
    📌 LOẠI: Script (Server)
    🔧 CÁCH TẠO:
        1. Vào ServerScriptService
        2. Insert > Script
        3. Đổi tên thành "StatusEffectHandler"
        4. Paste code này vào

    📋 CHỨC NĂNG:
        - ApplyStun: Khóa hành động người chơi
        - ApplyKnockback: Tung người chơi vào không khí
        - ApplyRagdoll: Bật chế độ ragdoll (mất kiểm soát)
        - RemoveRagdoll: Khôi phục lại sau ragdoll
--]]

local TweenService = game:GetService("TweenService")
local Config = require(game.ReplicatedStorage.Shared.CombatConfig)
local Remotes = require(game.ReplicatedStorage.Shared.RemoteEvents)

local StatusEffectHandler = {}

-- ══════════════════════════════════════════
--       TRẠNG THÁI NGƯỜI CHƠI
-- ══════════════════════════════════════════
-- Lưu trạng thái hiện tại để tránh xung đột
local playerStates = {}

local function getState(player)
    if not playerStates[player] then
        playerStates[player] = {
            isStunned  = false,
            isRagdoll  = false,
            isBlocking = false,
            isDashing  = false,
        }
    end
    return playerStates[player]
end

-- ══════════════════════════════════════════
--       APPLY STUN
-- ══════════════════════════════════════════
-- Khóa khả năng hành động trong thời gian ngắn

function StatusEffectHandler.ApplyStun(target, duration)
    local state = getState(target)
    if state.isStunned then return end -- Đã bị stun rồi

    local character = target.Character
    if not character then return end

    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
    if not humanoid then return end

    state.isStunned = true

    -- Dừng animation và khóa WalkSpeed không hoàn toàn (người vẫn trượt)
    -- Logic stun thực tế xử lý ở CombatHandler

    task.delay(duration, function()
        if playerStates[target] then
            playerStates[target].isStunned = false
        end
    end)
end

-- ══════════════════════════════════════════
--       APPLY KNOCKBACK
-- ══════════════════════════════════════════
-- Tung nhân vật theo hướng chỉ định

function StatusEffectHandler.ApplyKnockback(target, attacker, force)
    local character = target.Character
    if not character then return end

    local rootPart = character:FindFirstChild("HumanoidRootPart")
    local attackerRoot = attacker.Character and attacker.Character:FindFirstChild("HumanoidRootPart")
    if not rootPart or not attackerRoot then return end

    -- Tính hướng knockback (từ attacker → target)
    local direction = (rootPart.Position - attackerRoot.Position).Unit

    -- Áp dụng lực
    local knockbackVelocity = Instance.new("LinearVelocity")
    knockbackVelocity.MaxForce             = math.huge
    knockbackVelocity.RelativeTo           = Enum.ActuatorRelativeTo.World
    knockbackVelocity.Attachment0          = rootPart:FindFirstChild("RootAttachment") or Instance.new("Attachment", rootPart)
    knockbackVelocity.VectorVelocity       = Vector3.new(
        direction.X * force.Z,
        force.Y,
        direction.Z * force.Z
    )
    knockbackVelocity.Parent = rootPart

    -- Xóa lực sau thời gian ngắn
    game:GetService("Debris"):AddItem(knockbackVelocity, 0.15)

    -- Thông báo client phát hiệu ứng knockback
    Remotes.OnKnockback:FireClient(target, force)
end

-- ══════════════════════════════════════════
--       APPLY RAGDOLL
-- ══════════════════════════════════════════
-- Bật chế độ ragdoll - mất kiểm soát hoàn toàn

function StatusEffectHandler.ApplyRagdoll(target, duration)
    local state = getState(target)
    if state.isRagdoll then return end

    local character = target.Character
    if not character then return end

    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
    if not humanoid then return end

    state.isRagdoll = true
    humanoid.PlatformStand = true -- Bật ragdoll mode

    -- Tắt Motor6D (khớp nối) để người tự đổ
    for _, motor in ipairs(character:GetDescendants()) do
        if motor:IsA("Motor6D") then
            -- Thay Motor6D bằng BallSocketConstraint để ragdoll vật lý
            local attachment0 = Instance.new("Attachment")
            local attachment1 = Instance.new("Attachment")
            attachment0.CFrame = motor.C0
            attachment1.CFrame = motor.C1
            attachment0.Parent = motor.Part0
            attachment1.Parent = motor.Part1

            local ballSocket = Instance.new("BallSocketConstraint")
            ballSocket.Attachment0 = attachment0
            ballSocket.Attachment1 = attachment1
            ballSocket.LimitsEnabled = true
            ballSocket.TwistLimitsEnabled = true
            ballSocket.Parent = motor.Parent

            motor.Enabled = false -- Tắt motor, không xóa
        end
    end

    -- Khôi phục sau duration
    task.delay(duration, function()
        StatusEffectHandler.RemoveRagdoll(target)
    end)
end

-- ══════════════════════════════════════════
--       REMOVE RAGDOLL
-- ══════════════════════════════════════════

function StatusEffectHandler.RemoveRagdoll(target)
    local state = getState(target)
    if not state.isRagdoll then return end

    local character = target.Character
    if not character then return end

    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
    if not humanoid then return end

    -- Bật lại Motor6D
    for _, motor in ipairs(character:GetDescendants()) do
        if motor:IsA("Motor6D") then
            motor.Enabled = true
        end
    end

    -- Xóa các BallSocketConstraint tạm thời
    for _, v in ipairs(character:GetDescendants()) do
        if v:IsA("BallSocketConstraint") then
            v:Destroy()
        end
    end

    humanoid.PlatformStand = false
    state.isRagdoll = false
end

-- ══════════════════════════════════════════
--       GETTERS
-- ══════════════════════════════════════════

function StatusEffectHandler.IsStunned(player)
    return getState(player).isStunned
end

function StatusEffectHandler.IsRagdoll(player)
    return getState(player).isRagdoll
end

function StatusEffectHandler.SetBlocking(player, value)
    getState(player).isBlocking = value
end

function StatusEffectHandler.IsBlocking(player)
    return getState(player).isBlocking
end

function StatusEffectHandler.SetDashing(player, value)
    getState(player).isDashing = value
end

function StatusEffectHandler.IsDashing(player)
    return getState(player).isDashing
end

-- ══════════════════════════════════════════
--       DỌN DẸP KHI PLAYER RỜI GAME
-- ══════════════════════════════════════════
game:GetService("Players").PlayerRemoving:Connect(function(player)
    playerStates[player] = nil
end)

return StatusEffectHandler
