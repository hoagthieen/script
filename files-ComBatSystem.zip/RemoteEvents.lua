--[[
    📁 VỊ TRÍ FILE: ReplicatedStorage > Shared > RemoteEvents.lua
    📌 LOẠI: ModuleScript
    🔧 CÁCH TẠO:
        1. Vào ReplicatedStorage > Shared
        2. Insert > ModuleScript
        3. Đổi tên thành "RemoteEvents"
        4. Paste code này vào

    ⚠️ QUAN TRỌNG:
        - Script này TỰ ĐỘNG tạo RemoteEvent và RemoteFunction
        - Không cần tạo thủ công trong Explorer
        - Được require bởi cả Server lẫn Client
        - Luôn require cái này TRƯỚC khi dùng remotes
--]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local RemoteEvents = {}

-- ══════════════════════════════════════════
--       TẠO FOLDER CHỨA REMOTES
-- ══════════════════════════════════════════
local remotesFolder = ReplicatedStorage:FindFirstChild("CombatRemotes")
if not remotesFolder then
    remotesFolder = Instance.new("Folder")
    remotesFolder.Name = "CombatRemotes"
    remotesFolder.Parent = ReplicatedStorage
end

-- ══════════════════════════════════════════
--       HÀM TẠO REMOTE TỰ ĐỘNG
-- ══════════════════════════════════════════
local function getOrCreate(className, name)
    local existing = remotesFolder:FindFirstChild(name)
    if existing then return existing end

    local remote = Instance.new(className)
    remote.Name = name
    remote.Parent = remotesFolder
    return remote
end

-- ══════════════════════════════════════════
--       DANH SÁCH REMOTE EVENTS
-- ══════════════════════════════════════════
-- Client → Server (yêu cầu hành động)
RemoteEvents.RequestM1         = getOrCreate("RemoteEvent", "RequestM1")
RemoteEvents.RequestBlock      = getOrCreate("RemoteEvent", "RequestBlock")
RemoteEvents.RequestBlockEnd   = getOrCreate("RemoteEvent", "RequestBlockEnd")
RemoteEvents.RequestDash       = getOrCreate("RemoteEvent", "RequestDash")

-- Server → Client (thông báo kết quả)
RemoteEvents.OnHitConfirmed    = getOrCreate("RemoteEvent", "OnHitConfirmed")   -- Thông báo hit thành công
RemoteEvents.OnBlocked         = getOrCreate("RemoteEvent", "OnBlocked")        -- Thông báo bị block
RemoteEvents.OnDamaged         = getOrCreate("RemoteEvent", "OnDamaged")        -- Thông báo bị damage
RemoteEvents.OnKnockback       = getOrCreate("RemoteEvent", "OnKnockback")      -- Thông báo knockback
RemoteEvents.OnStaminaUpdate   = getOrCreate("RemoteEvent", "OnStaminaUpdate")  -- Cập nhật stamina UI
RemoteEvents.OnComboUpdate     = getOrCreate("RemoteEvent", "OnComboUpdate")    -- Cập nhật số combo

-- Server → Client (phát animation)
RemoteEvents.PlayAnimation     = getOrCreate("RemoteEvent", "PlayAnimation")
RemoteEvents.StopAnimation     = getOrCreate("RemoteEvent", "StopAnimation")

-- ══════════════════════════════════════════
--       REMOTE FUNCTIONS (trả về giá trị)
-- ══════════════════════════════════════════
RemoteEvents.GetCombatState    = getOrCreate("RemoteFunction", "GetCombatState") -- Lấy trạng thái combat

return RemoteEvents
