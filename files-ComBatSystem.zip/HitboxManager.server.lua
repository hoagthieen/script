--[[
    📁 VỊ TRÍ FILE: ServerScriptService > HitboxManager.server.lua
    📌 LOẠI: Script (Server)
    🔧 CÁCH TẠO:
        1. Vào ServerScriptService
        2. Insert > Script
        3. Đổi tên thành "HitboxManager"
        4. Paste code này vào

    📋 CHỨC NĂNG:
        - Tạo hitbox phía server (anti-cheat)
        - Raycast và overlap detection
        - Lọc các target hợp lệ
        - Trả về danh sách nhân vật bị trúng
        - Không cho phép tự hit bản thân
--]]

local Players   = game:GetService("Players")
local RunService = game:GetService("RunService")

local Config = require(game.ReplicatedStorage.Shared.CombatConfig)

local HitboxManager = {}

-- ══════════════════════════════════════════
--       TẠO HITBOX OVERLAP
-- ══════════════════════════════════════════
-- Tạo vùng overlap phía trước người chơi
-- Trả về: table chứa các humanoid bị trúng

function HitboxManager.CreateHitbox(attacker, hitboxSize, range)
    hitboxSize = hitboxSize or Config.M1.HitboxSize
    range      = range      or Config.M1.Range

    local character = attacker.Character
    if not character then return {} end

    local rootPart = character:FindFirstChild("HumanoidRootPart")
    if not rootPart then return {} end

    -- Tính toán vị trí hitbox phía trước nhân vật
    local hitboxCFrame = rootPart.CFrame * CFrame.new(0, 0, -(range / 2))

    -- Overlap params - chỉ detect Part
    local overlapParams = OverlapParams.new()
    overlapParams.FilterType = Enum.RaycastFilterType.Exclude
    overlapParams.FilterDescendantsInstances = {character} -- Loại bỏ chính mình

    local hitParts = workspace:GetPartBoundsInBox(hitboxCFrame, hitboxSize, overlapParams)

    -- ══════════════════════════════════════════
    --   LỌC VÀ TRẢ VỀ HUMANOID HỢP LỆ
    -- ══════════════════════════════════════════
    local hitResults = {}
    local hitCharacters = {} -- Tránh hit 1 người nhiều lần

    for _, part in ipairs(hitParts) do
        local hitCharacter = part:FindFirstAncestorWhichIsA("Model")
        if not hitCharacter then continue end
        if hitCharacters[hitCharacter] then continue end -- Đã hit rồi

        local humanoid = hitCharacter:FindFirstChildWhichIsA("Humanoid")
        if not humanoid then continue end
        if humanoid.Health <= 0 then continue end -- Bỏ qua nếu đã chết

        -- Kiểm tra có phải player không (tránh hit NPC ngoài ý muốn nếu cần)
        local targetPlayer = Players:GetPlayerFromCharacter(hitCharacter)

        hitCharacters[hitCharacter] = true
        table.insert(hitResults, {
            character = hitCharacter,
            humanoid  = humanoid,
            player    = targetPlayer,
            rootPart  = hitCharacter:FindFirstChild("HumanoidRootPart"),
        })
    end

    return hitResults
end

-- ══════════════════════════════════════════
--       DEBUG HITBOX (Chỉ dùng khi test)
-- ══════════════════════════════════════════
-- Bật DEBUG = true để thấy hitbox màu đỏ trong game
-- TẮT khi release: DEBUG = false

local DEBUG = false

function HitboxManager.DebugDraw(position, size, duration)
    if not DEBUG then return end

    local part = Instance.new("Part")
    part.Anchored     = true
    part.CanCollide   = false
    part.Transparency = 0.5
    part.Color        = Color3.fromRGB(255, 0, 0)
    part.Size         = size
    part.CFrame       = position
    part.Parent       = workspace

    game:GetService("Debris"):AddItem(part, duration or 0.1)
end

return HitboxManager
