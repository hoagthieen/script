--[[
    📁 VỊ TRÍ FILE: StarterPlayer > StarterPlayerScripts > CombatClient.client.lua
    📌 LOẠI: LocalScript
    🔧 CÁCH TẠO:
        1. Vào StarterPlayer
        2. Mở StarterPlayerScripts
        3. Insert > LocalScript
        4. Đổi tên thành "CombatClient"
        5. Paste code này vào

    📋 CHỨC NĂNG:
        - Lắng nghe input chuột / bàn phím
        - Gửi yêu cầu lên Server
        - Xử lý phản hồi từ Server (hit confirm, blocked, v.v.)
        - Hiệu ứng camera shake khi trúng đòn
        - KHÔNG xử lý logic combat (anti-cheat)

    🎮 PHÍM TẮT:
        Click Chuột Trái → M1 Combo
        F                → Block (giữ)
        Q                → Dash (theo hướng di chuyển)
--]]

local Players           = game:GetService("Players")
local UserInputService  = game:GetService("UserInputService")
local RunService        = game:GetService("RunService")
local TweenService      = game:GetService("TweenService")

local player            = Players.LocalPlayer
local camera            = workspace.CurrentCamera

local Remotes = require(game.ReplicatedStorage.Shared.RemoteEvents)
local Config  = require(game.ReplicatedStorage.Shared.CombatConfig)

-- ══════════════════════════════════════════
--       STATE CLIENT
-- ══════════════════════════════════════════
local isBlocking       = false
local canM1            = true     -- Client-side cooldown (chỉ để UX mượt, server quyết định)
local canDash          = true

-- ══════════════════════════════════════════
--       M1 COMBO - CLICK CHUỘT TRÁI
-- ══════════════════════════════════════════
UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed then return end -- Đang chat → bỏ qua

    -- ── M1: Click chuột trái ──
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        if not canM1 then return end
        if isBlocking then return end

        canM1 = false

        -- Gửi yêu cầu lên server
        Remotes.RequestM1:FireServer()

        -- Client-side cooldown (chỉ visual, server vẫn validate)
        task.delay(Config.M1.CooldownPerHit, function()
            canM1 = true
        end)
    end

    -- ── BLOCK: Giữ F ──
    if input.KeyCode == Enum.KeyCode.F then
        if isBlocking then return end
        isBlocking = true
        Remotes.RequestBlock:FireServer()
    end

    -- ── DASH: Nhấn Q ──
    if input.KeyCode == Enum.KeyCode.Q then
        if not canDash then return end
        canDash = false

        -- Tính hướng dash theo input di chuyển
        local character = player.Character
        local rootPart  = character and character:FindFirstChild("HumanoidRootPart")
        local dashDirection = Vector3.new(0, 0, -1) -- Mặc định dash về phía trước

        if rootPart then
            -- Lấy hướng từ WASD
            local moveDir = Vector3.new(
                (UserInputService:IsKeyDown(Enum.KeyCode.D) and 1 or 0) -
                (UserInputService:IsKeyDown(Enum.KeyCode.A) and 1 or 0),
                0,
                (UserInputService:IsKeyDown(Enum.KeyCode.S) and 1 or 0) -
                (UserInputService:IsKeyDown(Enum.KeyCode.W) and 1 or 0)
            )

            if moveDir.Magnitude > 0 then
                -- Chuyển hướng theo camera
                local camCFrame = camera.CFrame
                local flatCam   = CFrame.new(Vector3.zero, Vector3.new(camCFrame.LookVector.X, 0, camCFrame.LookVector.Z))
                dashDirection   = (flatCam * moveDir).Unit
            else
                dashDirection = -rootPart.CFrame.LookVector
            end
        end

        Remotes.RequestDash:FireServer(dashDirection)

        task.delay(Config.Dash.Cooldown, function()
            canDash = true
        end)
    end
end)

-- ══════════════════════════════════════════
--       BỎ BLOCK KHI THẢ F
-- ══════════════════════════════════════════
UserInputService.InputEnded:Connect(function(input, gameProcessed)
    if input.KeyCode == Enum.KeyCode.F then
        if not isBlocking then return end
        isBlocking = false
        Remotes.RequestBlockEnd:FireServer()
    end
end)

-- ══════════════════════════════════════════
--       CAMERA SHAKE KHI TRÚNG ĐÒN
-- ══════════════════════════════════════════
local function shakeCamera(magnitude, duration)
    local startTime   = tick()
    local connection

    connection = RunService.RenderStepped:Connect(function()
        local elapsed  = tick() - startTime
        if elapsed >= duration then
            connection:Disconnect()
            return
        end

        local progress = 1 - (elapsed / duration)  -- Giảm dần
        local offset   = Vector3.new(
            math.random(-100, 100) / 100 * magnitude * progress,
            math.random(-100, 100) / 100 * magnitude * progress,
            0
        )

        camera.CFrame = camera.CFrame * CFrame.new(offset)
    end)
end

-- ══════════════════════════════════════════
--       NHẬN PHẢN HỒI TỪ SERVER
-- ══════════════════════════════════════════

-- Xác nhận hit thành công
Remotes.OnHitConfirmed.OnClientEvent:Connect(function(targetPlayer, damage, wasBlocked)
    -- Hiệu ứng khi đánh trúng (rung nhẹ)
    shakeCamera(0.3, 0.15)

    -- TODO: Hiển thị damage number UI
    -- Gọi hàm trong CombatUI nếu cần
end)

-- Bị đánh trúng
Remotes.OnDamaged.OnClientEvent:Connect(function(damage, isFinalBlow)
    if isFinalBlow then
        shakeCamera(1.2, 0.4)  -- Rung mạnh khi bị đòn cuối
    else
        shakeCamera(0.5, 0.2)
    end
end)

-- Bị đánh block thành công (góc nhìn người defend)
Remotes.OnBlocked.OnClientEvent:Connect(function(damage)
    shakeCamera(0.2, 0.1) -- Rung nhẹ khi đỡ thành công
end)

-- Nhận knockback - hiệu ứng visual
Remotes.OnKnockback.OnClientEvent:Connect(function(force)
    -- Có thể thêm motion blur hoặc hiệu ứng screen ở đây
end)

print("[CombatClient] ✅ Input handler đã sẵn sàng!")
