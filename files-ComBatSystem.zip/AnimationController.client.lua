--[[
    📁 VỊ TRÍ FILE: StarterPlayer > StarterPlayerScripts > AnimationController.client.lua
    📌 LOẠI: LocalScript
    🔧 CÁCH TẠO:
        1. Vào StarterPlayer > StarterPlayerScripts
        2. Insert > LocalScript
        3. Đổi tên thành "AnimationController"
        4. Paste code này vào

    📋 CHỨC NĂNG:
        - Nhận lệnh phát animation từ Server (qua RemoteEvent)
        - Phát animation cho TẤT CẢ người chơi trong tầm nhìn
        - Quản lý animation track (tránh stack animation)
        - Priority: Action (combat) > Movement (walk/idle)
--]]

local Players  = game:GetService("Players")
local Remotes  = require(game.ReplicatedStorage.Shared.RemoteEvents)

-- ══════════════════════════════════════════
--       LƯU TRỮ ANIMATION TRACKS
-- ══════════════════════════════════════════
-- Format: activeTracks[player][trackName] = AnimationTrack
local activeTracks = {}

-- ══════════════════════════════════════════
--       HÀM LẤY ANIMATOR CỦA NHÂN VẬT
-- ══════════════════════════════════════════
local function getAnimator(character)
    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
    if not humanoid then return nil end

    local animator = humanoid:FindFirstChildWhichIsA("Animator")
    if not animator then
        animator = Instance.new("Animator")
        animator.Parent = humanoid
    end

    return animator
end

-- ══════════════════════════════════════════
--       PHÁT ANIMATION
-- ══════════════════════════════════════════
local function playAnimation(targetPlayer, animId, trackName, priority)
    local character = targetPlayer.Character
    if not character then return end

    local animator = getAnimator(character)
    if not animator then return end

    -- Dừng track cũ cùng tên nếu đang chạy
    if activeTracks[targetPlayer] and activeTracks[targetPlayer][trackName] then
        local oldTrack = activeTracks[targetPlayer][trackName]
        if oldTrack.IsPlaying then
            oldTrack:Stop(0.1)
        end
    end

    -- Tạo animation object
    local animObj = Instance.new("Animation")
    animObj.AnimationId = animId

    -- Load track
    local track = animator:LoadAnimation(animObj)
    track.Priority = priority or Enum.AnimationPriority.Action

    -- Lưu lại
    if not activeTracks[targetPlayer] then
        activeTracks[targetPlayer] = {}
    end
    activeTracks[targetPlayer][trackName] = track

    -- Phát
    track:Play(0.1)

    -- Dọn dẹp khi animation kết thúc
    track.Stopped:Connect(function()
        if activeTracks[targetPlayer] then
            activeTracks[targetPlayer][trackName] = nil
        end
        animObj:Destroy()
    end)
end

-- ══════════════════════════════════════════
--       DỪNG ANIMATION
-- ══════════════════════════════════════════
local function stopAnimation(targetPlayer, trackName)
    if not activeTracks[targetPlayer] then return end

    local track = activeTracks[targetPlayer][trackName]
    if track and track.IsPlaying then
        track:Stop(0.2)
        activeTracks[targetPlayer][trackName] = nil
    end
end

-- ══════════════════════════════════════════
--       NHẬN LỆNH TỪ SERVER
-- ══════════════════════════════════════════

Remotes.PlayAnimation.OnClientEvent:Connect(function(targetPlayer, animId, trackName, priorityStr)
    local priority = Enum.AnimationPriority[priorityStr] or Enum.AnimationPriority.Action
    playAnimation(targetPlayer, animId, trackName, priority)
end)

Remotes.StopAnimation.OnClientEvent:Connect(function(targetPlayer, trackName)
    stopAnimation(targetPlayer, trackName)
end)

-- ══════════════════════════════════════════
--       DỌN DẸP KHI PLAYER RỜI GAME
-- ══════════════════════════════════════════
Players.PlayerRemoving:Connect(function(player)
    activeTracks[player] = nil
end)

print("[AnimationController] ✅ Animation system sẵn sàng!")
