--[[
    📁 VỊ TRÍ FILE: ReplicatedStorage > Shared > CombatConfig.lua
    📌 LOẠI: ModuleScript
    🔧 CÁCH TẠO:
        1. Vào ReplicatedStorage
        2. Tạo Folder tên "Shared"
        3. Trong Shared → Insert > ModuleScript
        4. Đổi tên thành "CombatConfig"
        5. Paste code này vào
--]]

local CombatConfig = {}

-- ══════════════════════════════════════════
--              M1 COMBO CONFIG
-- ══════════════════════════════════════════
CombatConfig.M1 = {
    MaxCombo        = 5,         -- Số đòn trong 1 chuỗi combo
    ComboResetTime  = 1.2,       -- Thời gian reset combo nếu không bấm (giây)
    CooldownPerHit  = 0.35,      -- Thời gian chờ giữa mỗi đòn (giây)
    Range           = 8,         -- Tầm đánh (studs)
    HitboxSize      = Vector3.new(6, 5, 7), -- Kích thước hitbox
}

-- ══════════════════════════════════════════
--              DAMAGE CONFIG
-- ══════════════════════════════════════════
CombatConfig.Damage = {
    M1 = {10, 10, 10, 10, 20},  -- Damage từng đòn M1 (đòn 5 mạnh hơn)
    BlockReduction  = 0.8,       -- Block giảm 80% damage
    FinalBlowMulti  = 1.5,       -- Đòn cuối combo nhân thêm
}

-- ══════════════════════════════════════════
--              KNOCKBACK CONFIG
-- ══════════════════════════════════════════
CombatConfig.Knockback = {
    M1Base          = Vector3.new(0, 8, 35),   -- Lực knockback đòn thường
    M1Final         = Vector3.new(0, 18, 65),  -- Lực knockback đòn cuối (bay xa)
    StunDuration    = 0.4,       -- Thời gian stun sau mỗi đòn (giây)
    FinalStunDuration = 1.2,     -- Thời gian stun đòn cuối
    RagdollDuration = 1.5,       -- Thời gian ragdoll đòn cuối
}

-- ══════════════════════════════════════════
--              STAMINA CONFIG
-- ══════════════════════════════════════════
CombatConfig.Stamina = {
    Max             = 100,       -- Stamina tối đa
    RegenRate       = 15,        -- Lượng stamina hồi phục mỗi giây
    RegenDelay      = 1.5,       -- Thời gian chờ trước khi hồi stamina (giây)

    -- Chi phí
    DashCost        = 25,        -- Stamina tiêu cho Dash
    BlockCostPerSec = 10,        -- Stamina tiêu khi đang Block (mỗi giây)
    BlockHitCost    = 15,        -- Stamina tiêu khi đỡ 1 đòn
}

-- ══════════════════════════════════════════
--              DASH CONFIG
-- ══════════════════════════════════════════
CombatConfig.Dash = {
    Speed           = 120,       -- Tốc độ dash
    Duration        = 0.18,      -- Thời gian dash (giây)
    IframeDuration  = 0.3,       -- Thời gian invincible khi dash (giây)
    Cooldown        = 0.6,       -- Cooldown dash (giây)
}

-- ══════════════════════════════════════════
--              PLAYER STATS
-- ══════════════════════════════════════════
CombatConfig.Player = {
    MaxHP           = 100,
    WalkSpeed       = 16,
    BlockWalkSpeed  = 8,         -- Tốc độ đi khi block
}

return CombatConfig
